"""Data models for the RA Autohaus Tracker."""
